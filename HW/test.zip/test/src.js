/**
 * Evgeni Dikerman
 * *** More then one hour... ***
 */

(function () {
    /**
     * Main app function
     * @param _shapesArr the available shapes
     */
    function myShapesApp(_shapesArr) {
        var app = this;

        app.settings = {
            sizeRange: {
                min: 20,
                max: 300
            },
            speedRange: {
                min: 1,
                max: 10,
                base: 200
            },
            directionRange: 10

        };

        app.initApp = initApp;

        app.shapesPrototypes = _shapesArr;

        function initApp() {
            document.addEventListener('DOMContentLoaded', function () {

                window.onclick = function (event) {
                    createNewShape(event);
                }
            });
        }

        function createNewShape(mouseClickEvent) {
            //choose shape
            var randShape = Math.floor(Math.random() * app.shapesPrototypes.length);

            //get click position
            var position = {
                x: mouseClickEvent.clientX,
                y: mouseClickEvent.clientY
            };

            //add new shape
            var shape = new app.shapesPrototypes[randShape](app.settings, position);
            shape.init();

            //create html element and add it to the DOM
            var divElem = document.createElement('div');
            divElem = shape.applyStyle(divElem);
            document.getElementsByTagName('body')[0].appendChild(divElem);
            shape.startMovment(divElem);
        }
    }

    /**
     * Shape prototype
     * @param _settings look and feel settings
     * @param _position
     * @constructor
     */
    function Shape(_settings, _position) {
        var shape = this;

        shape.size = {
            x: 0,
            y: 0,
            borderRadius: 0
        };

        shape.speed = 0;

        shape.position = {
            x: 0,
            y: 0
        };

        shape.direction = {
            x: 0,
            y: 0
        };

        shape.init = init;
        shape.applyStyle = applyStyle;
        shape.getRandomInt = getRandomInt;
        shape.getRandomSize = getRandomSize;
        shape.startMovment = startMovement;

        function init() {
            shape.position = _position;
            shape.speed = getRandomSpeed(_settings);
            shape.direction = getRandomDirection(_settings);
        }

        function applyStyle(elem, onlyPosition) {
            elem.style.top = shape.position.y + 'px';
            elem.style.left = shape.position.x + 'px';
            if (onlyPosition) {
                return elem;
            }

            elem.style.width = shape.size.x + 'px';
            elem.style.height = shape.size.y + 'px';

            elem.style.borderRadius = shape.size.borderRadius + 'px';
            elem.className = "general-shape";
            return elem;
        }

        function startMovement(elem) {
            var speed = _settings.speedRange.base / shape.speed;
            setInterval(function () {
                doStep();
                applyStyle(elem, true)
            }, speed);
        }

        function doStep() {
            checkWalls();
            shape.position.x += shape.direction.x;
            shape.position.y += shape.direction.y;
        }

        function checkWalls() {
            if (shape.position.x <= 0) {
                shape.direction.x *= (-1);
            }
            if (shape.position.y <= 0) {
                shape.direction.y *= (-1);
            }
            if ((shape.position.x + shape.size.x) >= window.screen.availWidth) {
                shape.direction.x *= (-1);
            }
            if ((shape.position.y + shape.size.y) >= window.screen.availHeight) {
                shape.direction.y *= (-1);
            }
        }

        function getRandomSpeed(_settings) {
            var minSpeed = _settings.speedRange.min;
            var maxSpeed = _settings.speedRange.max;

            return getRandomInt(minSpeed, maxSpeed);
        }

        function getRandomDirection(_settings) {
            var dir = _settings.directionRange;

            return {
                x: getRandomInt(dir * (-1), dir),
                y: getRandomInt(dir * (-1), dir)
            }
        }

        function getRandomSize(_settings) {
            var minSize = _settings.sizeRange.min;
            var maxSize = _settings.sizeRange.max;

            return {
                x: getRandomInt(minSize, maxSize),
                y: getRandomInt(minSize, maxSize),
                borderRadius: 0
            }
        }

        function getRandomInt(min, max) {
            return Math.floor(Math.random() * (max - min + 1)) + min;
        }
    }

    function Circle(_settings, _position) {
        Shape.call(this, _settings, _position);
        this.getRandomSize = function (_settings) {
            var minSize = _settings.sizeRange.min;
            var maxSize = _settings.sizeRange.max;
            var size = this.getRandomInt(minSize, maxSize);
            return {
                x: size,
                y: size,
                borderRadius: Math.floor(size / 2)
            }
        };

        this.size = this.getRandomSize(_settings);
    }

    Circle.prototype.constructor = Circle;
    Circle.prototype = Object.create(Shape.prototype);

    function Rectangle(_settings, _position) {
        Shape.call(this, _settings, _position);
        this.getRandomSize = function (_settings) {
            var minSize = _settings.sizeRange.min;
            var maxSize = _settings.sizeRange.max;

            return {
                x: this.getRandomInt(minSize, maxSize),
                y: this.getRandomInt(minSize, maxSize),
                borderRadius: 0
            }
        };

        this.size = this.getRandomSize(_settings);
    }

    Rectangle.prototype.constructor = Rectangle;
    Rectangle.prototype = Object.create(Shape.prototype);


    // init and start the main method
    var app = new myShapesApp([Circle, Rectangle]);
    app.initApp();

})();

